<!-- <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="dashboard.php">لوحة التحكم</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">

      <li class="nav-item">
        <a class="nav-link" href="register.php">تسجيل مستخدم جديد</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="login.php">تسجيل الدخول</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="upload.php">رفع ملف</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="all_files.php">جميع الملفات</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="shared.php">الملفات المشتركة</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="download.php">تحميل ملف</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="folder.php">انشاء مجلد</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="upload2.php">رفع إلى مجلد</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="logout.php">تسجيل الخروج</a>
      </li>

    </ul>
  </div>
</nav>
 -->
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
.custom-navbar {
  background-color: #222;
  color: #fff;
  padding: 10px 20px;
  direction: rtl;
}

.nav-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
}

.brand {
  color: #fff;
  text-decoration: none;
  font-weight: bold;
  font-size: 1.2rem;
}

.menu-toggle {
  font-size: 24px;
  background: none;
  border: none;
  color: white;
  cursor: pointer;
  display: none;
}

.nav-links {
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
}

.nav-links li a {
  color: #fff;
  text-decoration: none;
  padding: 8px 12px;
  transition: background 0.3s;
}

.nav-links li a:hover {
  background-color: #444;
  border-radius: 5px;
}

/* الهاتف */
@media (max-width: 768px) {
  .menu-toggle {
    display: block;
  }

  .nav-links {
    display: none;
    flex-direction: column;
    width: 100%;
    margin-top: 10px;
  }

  .nav-links.active {
    display: flex;
  }

  .nav-links li {
    border-top: 1px solid #333;
    padding: 10px 0;
  }

  .nav-links li a {
    padding: 10px;
  }
}
        </style>
</head>
<body>
    <nav class="custom-navbar">
  <div class="nav-container">
    <a href="dashboard.php" class="brand">لوحة التحكم</a>
    <button class="menu-toggle" id="menu-toggle">&#9776;</button>
    <ul class="nav-links" id="nav-links">
      <li><a href="register.php">تسجيل مستخدم جديد</a></li>
      <li><a href="login.php">تسجيل الدخول</a></li>
      <li><a href="upload.php">رفع ملف</a></li>
      <li><a href="all_files.php">جميع الملفات</a></li>
      <li><a href="shared.php">الملفات المشتركة</a></li>
      <li><a href="download.php">تحميل ملف</a></li>
      <li><a href="folders.php">إنشاء مجلد</a></li>
      <li><a href="upload2.php">رفع إلى مجلد</a></li>
      <li><a href="logout.php">تسجيل الخروج</a></li>
    </ul>
  </div>
</nav>
<script>
    const menuToggle = document.getElementById('menu-toggle');
    const navLinks = document.getElementById('nav-links');

    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });
    </script>
    
</body>
</html> -->


<?php
/* * /
$current = basename($_SERVER['PHP_SELF']);
function active($file) {
    global $current;
    return $current === $file ? 'active' : '';
}
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php">📂 إدارة الملفات</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= active('dashboard.php') ?>" href="dashboard.php">🏠 لوحة التحكم</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= active('upload.php') ?>" href="upload.php">⬆️ رفع الملفات</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= active('files.php') ?>" href="files.php">📁 ملفاتي</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= active('folders.php') ?>" href="folders.php">📂 التصنيفات</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= active('shared.php') ?>" href="shared.php">🔗 الروابط المشتركة</a>
                </li>
            </ul>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link text-danger" href="logout.php">🚪 تسجيل الخروج</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php
/*
$current = basename($_SERVER['PHP_SELF']);
function active($file) {
    global $current;
    return $current === $file ? 'text-white font-semibold' : 'text-gray-300 hover:text-white';
}
?>

<nav class="bg-gray-800 mb-4">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
            <!-- Logo -->
            <div class="flex items-center">
                <a href="index.php" class="text-white text-xl font-bold">📂 إدارة الملفات</a>
            </div>
            
            <!-- Mobile button -->
            <div class="md:hidden">
                <button id="menu-toggle" class="text-gray-300 hover:text-white focus:outline-none">
                    <svg class="h-6 w-6 fill-current" viewBox="0 0 24 24">
                        <path fill-rule="evenodd" d="M4 5h16M4 12h16M4 19h16" />
                    </svg>
                </button>
            </div>
            
            <!-- Menu items -->
            <div id="menu" class="hidden md:flex md:items-center w-full md:w-auto">
                <ul class="flex flex-col md:flex-row md:space-x-6 md:space-x-reverse mt-4 md:mt-0">
                    <li><a class="block px-3 py-2 rounded <?= active('dashboard.php') ?>" href="dashboard.php">🏠 لوحة التحكم</a></li>
                    <li><a class="block px-3 py-2 rounded <?= active('upload.php') ?>" href="upload.php">⬆️ رفع الملفات</a></li>
                    <li><a class="block px-3 py-2 rounded <?= active('files.php') ?>" href="files.php">📁 ملفاتي</a></li>
                    <li><a class="block px-3 py-2 rounded <?= active('folders.php') ?>" href="folders.php">📂 التصنيفات</a></li>
                    <li><a class="block px-3 py-2 rounded <?= active('shared.php') ?>" href="shared.php">🔗 الروابط المشتركة</a></li>
                </ul>
            </div>
            
            <!-- Logout -->
            <div class="hidden md:block">
                <a class="text-red-400 hover:text-red-600 px-3 py-2 rounded" href="logout.php">🚪 تسجيل الخروج</a>
            </div>
        </div>
        
        <!-- Mobile Logout -->
        <div class="md:hidden mt-2 text-right">
            <a class="text-red-400 hover:text-red-600 px-3 py-2 rounded block" href="logout.php">🚪 تسجيل الخروج</a>
        </div>
    </div>
</nav>

<script>
    // Toggle menu for mobile
    document.getElementById('menu-toggle').addEventListener('click', function () {
        const menu = document.getElementById('menu');
        menu.classList.toggle('hidden');
    });
</script>

        * /?>
        <?php
$current = basename($_SERVER['PHP_SELF']);
function active($file) {
    global $current;
    return $current === $file ? 'text-white font-bold' : 'text-gray-300 hover:text-white';
}
?>

<nav class="bg-gray-800 mb-4">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
            <!-- الشعار -->
            <a href="index.php" class="text-white text-xl font-bold">📂 إدارة الملفات</a>

            <!-- زر القائمة للجوال -->
            <div class="md:hidden">
                <button id="menu-toggle" class="text-gray-300 hover:text-white focus:outline-none">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2"
                         viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>
            </div>

            <!-- القائمة الرئيسية لأجهزة الكمبيوتر -->
            <ul class="hidden md:flex space-x-4 space-x-reverse items-center">
                <li><a class="px-3 py-2 rounded <?= active('dashboard.php') ?>" href="dashboard.php">🏠 لوحة التحكم</a></li>
                <li><a class="px-3 py-2 rounded <?= active('upload.php') ?>" href="upload.php">⬆️ رفع الملفات</a></li>
                <li><a class="px-3 py-2 rounded <?= active('files.php') ?>" href="files.php">📁 ملفاتي</a></li>
                <li><a class="px-3 py-2 rounded <?= active('folders.php') ?>" href="folders.php">📂 التصنيفات</a></li>
                <li><a class="px-3 py-2 rounded <?= active('shared.php') ?>" href="shared.php">🔗 الروابط المشتركة</a></li>
                <li><a class="text-red-400 hover:text-red-600 px-3 py-2 rounded" href="logout.php">🚪 تسجيل الخروج</a></li>
            </ul>
        </div>

        <!-- القائمة الخاصة بالجوال -->
        <div id="mobile-menu" class="md:hidden hidden mt-4">
            <ul class="space-y-2">
                <li><a class="block px-3 py-2 rounded <?= active('dashboard.php') ?>" href="dashboard.php">🏠 لوحة التحكم</a></li>
                <li><a class="block px-3 py-2 rounded <?= active('upload.php') ?>" href="upload.php">⬆️ رفع الملفات</a></li>
                <li><a class="block px-3 py-2 rounded <?= active('files.php') ?>" href="files.php">📁 ملفاتي</a></li>
                <li><a class="block px-3 py-2 rounded <?= active('folders.php') ?>" href="folders.php">📂 التصنيفات</a></li>
                <li><a class="block px-3 py-2 rounded <?= active('shared.php') ?>" href="shared.php">🔗 الروابط المشتركة</a></li>
                <li><a class="block text-red-400 hover:text-red-600 px-3 py-2 rounded" href="logout.php">🚪 تسجيل الخروج</a></li>
            </ul>
        </div>
    </div>
</nav>

<script>
    // إظهار / إخفاء القائمة على الجوال
    document.getElementById('menu-toggle').addEventListener('click', function () {
        const menu = document.getElementById('mobile-menu');
        menu.classList.toggle('hidden');
    });
</script>
*/
// ?>
<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Font Awesome لأيقونات -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    integrity="sha512-...hash..."
    crossorigin="anonymous"
    referrerpolicy="no-referrer"
  />

  <style>
    :root {
      --main-bg: #0f252a;
      --main-text: #fff;
      --hover-bg: #444;
      --hover-text: #ffcc00;
      --brand-color: #00bcd4;
    }

    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f9f9f9;
    }

    .custom-navbar {
      background-color: var(--main-bg);
      color: var(--main-text);
      padding: 10px 20px;
      direction: rtl;
    }

    .nav-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
    }

    .brand {
      color: var(--brand-color);
      text-decoration: none;
      font-weight: bold;
      font-size: 1.4rem;
    }

    .menu-toggle {
      font-size: 24px;
      background: none;
      border: none;
      color: var(--main-text);
      cursor: pointer;
      display: none;
    }

    .nav-links {
      list-style: none;
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      padding: 0;
      margin: 0;
    }

    .nav-links li {
      padding: 0;
      margin: 0;
    }

    .nav-links li a {
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--main-text);
      text-decoration: none;
      padding: 10px 15px;
      transition: background 0.3s, color 0.3s;
      font-weight: bold;
      background-color: transparent;
    }

    .nav-links li a:hover {
      background-color: var(--hover-bg);
      color: var(--hover-text);
      border-radius: 5px;
    }

    @media (max-width: 768px) {
      .menu-toggle {
        display: block;
      }

      .nav-links {
        display: none;
        flex-direction: column;
        width: 100%;
        margin-top: 10px;
      }

      .nav-links.active {
        display: flex;
      }

      .nav-links li {
        border-top: 1px solid #333;
      }

      .nav-links li a {
        padding: 15px;
      }
    }
  </style>
</head>
<body>
  <nav class="custom-navbar">
    <div class="nav-container">
      <a href="dashboard.php" class="brand">لوحة التحكم</a>
      <button class="menu-toggle" id="menu-toggle">&#9776;</button>
      <ul class="nav-links" id="nav-links">
        <!-- <li><a href="register.php"><i class="fas fa-user-plus"></i> تسجيل مستخدم جديد</a></li>
        <li><a href="login.php"><i class="fas fa-sign-in-alt"></i> تسجيل الدخول</a></li>-->
        <li><a href="folders.php"><i class="fas fa-folder-plus"></i> إنشاء مجلد</a></li>
		<li><a href="upload2.php"><i class="fas fa-cloud-upload-alt"></i> رفع إلى مجلد</a></li>

        <li><a href="upload.php"><i class="fas fa-upload"></i> رفع ملف</a></li>
        <li><a href="files.php"><i class="fas fa-folder-open"></i> عرض الملفات</a></li>
        <li><a href="all_files.php"><i class="fas fa-folder-open"></i> جميع الملفات</a></li>
        <li><a href="shared.php"><i class="fas fa-share-alt"></i> الملفات المشتركة</a></li>
        <li><a href="download.php"><i class="fas fa-download"></i> تنزيل ملف</a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a></li>
      </ul>
    </div>
  </nav>

  <script>
    const menuToggle = document.getElementById('menu-toggle');
    const navLinks = document.getElementById('nav-links');

    menuToggle.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });
  </script>
</body>
</html>
